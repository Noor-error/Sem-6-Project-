<?php include('admin/includes/dbconnection.php'); ?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>Teacher Subject Allocation System</title>
        <!-- Favicon-->
        <link rel="icon" type="image/x-icon" href="assets/favicon.ico" />
        <!-- Core theme CSS (includes Bootstrap)-->
        <link href="css/styles.css" rel="stylesheet" />

        <!-- Internal CSS -->
        <style>
            body {
                font-family: 'Arial', sans-serif;
                background-image: url('assets/back.jpeg'); /* Change this to your new background image */
                background-size: cover; /* Ensure the image covers the entire background */
                background-position: center; /* Center the background image */
                color: #fff;
                margin: 0;
                padding: 0;
                min-height: 100vh;
            }

            .navbar {
                background-color: #222;
            }
            .navbar-brand {
                font-size: 1.6rem;
                font-weight: bold;
                color: #ffcc00;
            }
            .navbar-nav .nav-link {
                color: #f8f9fa !important;
                font-size: 1.2rem;
                padding-left: 15px;
                padding-right: 15px;
                transition: all 0.3s;
            }
            .navbar-nav .nav-link:hover {
                color: #ffcc00 !important;
                transform: scale(1.1);
            }

            header {
                background: #333;
                color: #fff;
                padding: 80px 0;
                text-align: center;
                border-bottom: 5px solid rgba(0, 255, 242, 0);
            }
            h1 {
                font-size: 3.5rem;
                font-weight: bold;
                text-shadow: 2px 2px 8px rgba(0, 0, 0, 0.5);
            }

            .card {
                border: none;
                border-radius: 10px;
                box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
                margin-bottom: 30px;
                background: #fff;
                transition: transform 0.3s ease;
            }
            .card:hover {
                transform: translateY(-10px);
            }
            .card-header {
                background-color: #28a745;
                color: white;
                font-size: 1.2rem;
                padding: 15px;
                border-radius: 10px 10px 0 0;
                text-align: center;
            }
            .card-body {
                padding: 30px;
            }

            .table {
                width: 100%;
                margin: 20px 0;
                border-collapse: collapse;
            }
            .table th, .table td {
                padding: 12px;
                text-align: left;
                border-bottom: 1px solid #ddd;
                transition: background-color 0.3s ease;
            }
            .table-striped tbody tr:nth-of-type(odd) {
                background-color: #f2f2f2;
            }
            .table-striped tbody tr:hover {
                background-color: #f0e68c;
                cursor: pointer;
            }
            .table-bordered th, .table-bordered td {
                border: 1px solid #ddd;
            }
            .table thead {
                background-color: #007bff;
                color: white;
            }

            .input-group {
                margin-bottom: 20px;
            }
            .form-control {
                border-radius: 25px;
                padding: 10px;
                font-size: 1.1rem;
                transition: all 0.3s ease;
            }
            .form-control:focus {
                outline: none;
                box-shadow: 0 0 8px rgba(0, 123, 255, 0.5);
                border-color: #007bff;
            }
            .btn-primary {
                background-color: #ffcc00;
                color: black;
                border-radius: 25px;
                font-size: 1.1rem;
                padding: 10px 20px;
                transition: background-color 0.3s ease;
            }
            .btn-primary:hover {
                background-color: #ffc107;
                transform: scale(1.05);
            }

            footer {
                background-color: #222;
                color: white;
                text-align: center;
                padding: 20px;
                position: relative;
                bottom: 0;
                width: 100%;
                margin-top: 40px;
            }

        </style>
    </head>
    <body>
        <!-- Responsive navbar-->
        <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
            <div class="container">
                <a class="navbar-brand" href="#!">Teacher Subject Allocation System (TSAS)</a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
                        <li class="nav-item"><a class="nav-link" href="index.php">Home</a></li>
                        <li class="nav-item"><a class="nav-link" href="admin/login.php">Admin</a></li>
                    </ul>
                </div>
            </div>
        </nav>

        <header style="background: transparent;"> <!-- Changed here -->
    <div class="container text-center">
        <!-- Logo -->
        <div class="logo" style="margin-bottom: 20px;">
            <img src="assets/logo.png" alt="TSAS Logo" style="width: 150px; height: auto; transition: transform 0.5s ease;" onmouseover="this.style.transform='scale(1.1)'" onmouseout="this.style.transform='scale(1)'">
        </div>
        <!-- Title and Tagline -->
        <h1 class="fw-bolder" style="font-size: 3.8rem; color: #fff; font-weight: 700; text-shadow: 2px 2px 10px rgba(0, 0, 0, 0.6);">Teacher Subject Allocation System</h1>
        <p class="lead mb-4" style="font-size: 1.3rem; color: #f8f9fa;">Efficiently allocate subjects to the right teachers.</p>
    </div>
</header>
<style>
    @keyframes fadeIn {
        from {
            opacity: 0;
        }
        to {
            opacity: 1;
        }
    }
</style>


        <!-- Page content-->
        <div class="container">
            <div class="row">
                <!-- Blog entries-->
                <!-- Side widgets-->
                <div class="col-lg-12">
                    <!-- Search widget-->
                    <div class="card mb-4">
                        <div class="card-header">Search</div>
                        <form method="post">
                            <div class="card-body">
                                <div class="input-group">
                                    <input class="form-control" type="text" placeholder="Search teacher by name or emp id" aria-label="Enter search term..." aria-describedby="button-search" name="searchdata" />
                                    <button class="btn btn-primary" id="button-search" name="search" type="submit">Go!</button>
                                </div>
                            </div>
                        </form>
                    </div>

                    <?php
                    if(isset($_POST['search'])) { 
                        $sdata = $_POST['searchdata'];
                    ?>
                    <div class="card mb-4">
                        <div class="card-header">Categories</div>
                        <div class="card-body">
                            <h4 align="center">Result against "<?php echo $sdata;?>" keyword</h4>
                            <table class="table table-striped table-bordered">
                                <thead>
                                    <tr>
                                        <th>S.No</th>
                                        <th>Employee Name</th>
                                        <th>Course Name</th>
                                        <th>Subject Name</th>
                                        <th>Allocation Date</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    $sql = "SELECT tblsuballocation.ID as suballid, tblsuballocation.CourseID, tblsuballocation.Teacherempid, tblsuballocation.Subid, tblsuballocation.AllocationDate, tblteacher.EmpID, tblteacher.FirstName, tblteacher.LastName, tblcourse.BranchName, tblcourse.CourseName, tblsubject.ID, tblsubject.CourseID, tblsubject.SubjectFullname, tblsubject.SubjectShortname, tblsubject.SubjectCode from tblsuballocation join tblteacher on tblteacher.EmpID=tblsuballocation.Teacherempid join tblcourse on tblcourse.ID=tblsuballocation.CourseID join tblsubject on tblsubject.ID=tblsuballocation.Subid where tblsuballocation.Teacherempid like '%$sdata%' || tblteacher.FirstName like '%$sdata%'";
                                    $query = $dbh->prepare($sql);
                                    $query->execute();
                                    $results = $query->fetchAll(PDO::FETCH_OBJ);
                                    $cnt = 1;
                                    if($query->rowCount() > 0) {
                                        foreach($results as $row) { ?>
                                            <tr>
                                                <td><?php echo htmlentities($cnt);?></td>
                                                <td><?php echo htmlentities($row->FirstName);?> <?php echo htmlentities($row->LastName);?>(<?php echo htmlentities($row->Teacherempid);?>)</td>
                                                <td><?php echo htmlentities($row->BranchName);?>(<?php echo htmlentities($row->CourseName);?>)</td>
                                                <td><?php echo htmlentities($row->SubjectFullname);?>(<?php echo htmlentities($row->SubjectCode);?>)</td>
                                                <td><?php echo htmlentities($row->AllocationDate);?></td>
                                            </tr>
                                        <?php $cnt = $cnt + 1; } 
                                    } else { ?>
                                        <tr>
                                            <td colspan="5">No record found against this search</td>
                                        </tr>
                                    <?php } ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <?php } ?>
                </div>
            </div>
        </div>

        <!-- Footer-->
        <footer>
            <p>© 2025 Teacher Subject Allocation System. All rights reserved.</p>
        </footer>

        <!-- Bootstrap core JS-->
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
        <!-- Core theme JS-->
        <script src="js/scripts.js"></script>
    </body>
</html>