#include <iostream>
using namespace std ;

class Staff {
    protected :
    int code ;
    char name[20];
    

};

class Teacher : public Staff {
    protected :
    char Subject[20] ;
    public :
    void read(){
        cout<<"Enter your Subject";
        cin>>Subject;
    }
    void display(){
        cout<<"The name of the subject is "<<Subject;
    }
};

int main(){
    Teacher Obj1 ;
    Obj1.display();

}